README
-----:q

git clone https://github.com/splicebox/Jutils.git
cd Jutils

base_dir="data"
result_dir="jutils_leafcutter_out"
python3 jutils.py convert-results --leafcutter-dir "${base_dir}/leafcutter" \
                                  --out-dir "${result_dir}"

# Heatmap
# DSR with aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/leafcutter_results.tsv" \
                          --meta-file "${base_dir}/leafcutter_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --aggregate --prefix leafcutter

# DSR without aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/leafcutter_results.tsv" \
                          --meta-file "${base_dir}/leafcutter_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --prefix leafcutter

# Heatmap
# DSR with aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/leafcutter_results.tsv" \
                          --meta-file "${base_dir}/leafcutter_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --aggregate --prefix leafcutter \
                          --unsupervised

# DSR without aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/leafcutter_results.tsv" \
                          --meta-file "${base_dir}/leafcutter_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --prefix leafcutter \
                          --unsupervised


# Sashimi Plot
# MntJULiP: (used g006855 for jutils paper)
python3 jutils.py sashimi --tsv-file "${result_dir}/leafcutter_results.tsv" \
                          --meta-file "${base_dir}/leafcutter_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --group-id "clu_1171_NA" \
                          --gtf "${base_dir}/gencode.vM17.annotation.clean.gtf.gz" \
                          --shrink
git clone https://github.com/splicebox/Jutils.git
cd Jutils

base_dir="data"
result_dir="jutils_nmtjulip_out"
python3 jutils.py convert-results --mntjulip-dir "${base_dir}/mntjulip" \
                                  --out-dir "${result_dir}"

# Heatmap
# DSR with aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSR_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --aggregate --prefix mntjulip_DSR

# DSR without aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSR_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --prefix mntjulip_DSR

# DSA
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSA_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --avg 50 --fold-change 2 --prefix mntjulip_DSA

# Heatmap
# DSR with aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSR_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --aggregate --prefix mntjulip_DSR \
                          --unsupervised

# DSR without aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSR_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --prefix mntjulip_DSR \
                          --unsupervised

# DSA, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/mntjulip_DSA_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --prefix mntjulip_DSA \
                          --unsupervised

# Sashimi Plot
# MntJULiP: (used g006855 for jutils paper)
python3 jutils.py sashimi --tsv-file "${result_dir}/mntjulip_DSR_results.tsv" \
                          --meta-file "${base_dir}/mntjulip_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --group-id "g001499" \
                          --gtf "${base_dir}/gencode.vM17.annotation.clean.gtf.gz" \
                          --shrink
git clone https://github.com/splicebox/Jutils.git
cd Jutils

base_dir="data"
result_dir="jutils_rmats_out"
python3 jutils.py convert-results --rmats-dir "${base_dir}/rmats" \
                                  --out-dir "${result_dir}"

# Heatmap
# DSR without aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/rmats_ReadsOnTargetAndJunctionCounts_results.tsv" \
                          --meta-file "${base_dir}/rmats_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --prefix rmats_ReadsOnTargetAndJunctionCounts

# DSR without aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/rmats_ReadsOnTargetAndJunctionCounts_results.tsv" \
                          --meta-file "${base_dir}/rmats_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --prefix rmats_ReadsOnTargetAndJunctionCounts \
                          --unsupervised

# DSR without aggregate
python3 jutils.py heatmap --tsv-file "${result_dir}/rmats_JunctionCountOnly_results.tsv" \
                          --meta-file "${base_dir}/rmats_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --p-value 0.05 --q-value 1 --dpsi 0.2 --prefix rmats_JunctionCountOnly

# DSR without aggregate, unsupervised
python3 jutils.py heatmap --tsv-file "${result_dir}/rmats_JunctionCountOnly_results.tsv" \
                          --meta-file "${base_dir}/rmats_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --prefix rmats_JunctionCountOnly \
                          --unsupervised


##### rmat MXE
python3 jutils.py sashimi --tsv-file "${result_dir}/rmats_ReadsOnTargetAndJunctionCounts_results.tsv" \
                          --meta-file "${base_dir}/rmats_meta_file.tsv" \
                          --out-dir "${result_dir}" \
                          --group-id "J57027" \
                          --gtf "${base_dir}/gencode.vM17.annotation.clean.gtf.gz" \
                          --shrink
